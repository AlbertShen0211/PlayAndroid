package com.flyco.dialog.listener;

public interface OnBtnClickL {
	void onBtnClick();
}
