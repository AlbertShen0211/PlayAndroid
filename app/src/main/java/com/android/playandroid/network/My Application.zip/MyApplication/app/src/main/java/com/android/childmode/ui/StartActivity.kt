package com.android.childmode.ui

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Message
import com.android.childmode.R
import com.android.childmode.ui.login.LoginActivity
import com.android.framework.ext.start
import com.util.ktx.base.BaseActivity
import com.util.ktx.ext.startKtxActivity

class StartActivity : BaseActivity() {
    var mHandler: Handler = @SuppressLint("HandlerLeak")
    object : Handler() {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
        }
    }

    override fun getLayoutResId() = R.layout.activity_start

    override fun initView() {


    }

    override fun initData() {
        mHandler.postDelayed({
            start<LoginActivity>()
            this.finish()
        }, 2000)
    }


}