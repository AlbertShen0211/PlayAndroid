package com.android.childmode.bean

/**
 * Created by Albert on 2020/5/10.
 * Description:
 *
 * {
"Version": "1",
"Charset": "UTF-8",
"Variables": {
"cookiepre": "jcsA_d25e_",
"auth": null,
"saltkey": "u8968gpu",
"member_uid": "0",
"member_username": "",
"member_email": null,
"member_avatar": "https:\/\/forum.chasedream.com\/uc_server\/avatar.php?uid=0&size=small",
"groupid": "7",
"formhash": "2d10a5a8",
"ismoderator": null,
"readaccess": "1",
"notice": {
"newpush": "0",
"newpm": "0",
"newprompt": "0",
"newmypost": "0"
}
},
"Message": {
"messageval": "to_login\/\/1",
"messagestr": "您需要先登录才能继续本操作"
}
}
 *
 *
 *
 */
data class ResentMailBean(
    val Charset: String,
    val Message: Message,
    val Variables: Variables5,
    val Version: String
)

data class Variables5(
    val auth: Any,
    val cookiepre: String,
    val formhash: String,
    val groupid: String,
    val ismoderator: Any,
    val member_avatar: String,
    val member_email: Any,
    val member_uid: String,
    val member_username: String,
    val notice: Notice,
    val readaccess: String,
    val saltkey: String
)
