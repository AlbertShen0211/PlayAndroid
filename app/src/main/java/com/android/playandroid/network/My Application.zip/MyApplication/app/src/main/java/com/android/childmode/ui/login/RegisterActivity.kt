package com.android.childmode.ui.login

import android.graphics.drawable.BitmapDrawable
import android.util.Log
import android.view.View
import androidx.lifecycle.rxLifeScope
import com.android.childmode.R
import com.android.childmode.bean.*
import com.android.childmode.databinding.ActivityRegisterBinding
import com.android.childmode.ui.WebViewActivity
import com.android.childmode.util.VerifyUtil
import com.android.childmode.util.VerifyUtil.isContainAll
import com.android.childmode.util.VerifyUtil.isLengthLegal
import com.android.childmode.viewmodel.LoginViewModel
import com.android.framework.ext.click
import com.android.framework.ext.start
import com.android.framework.ext.toast
import com.util.ktx.base.BaseVMActivity
import com.util.ktx.ext.Hash
import com.util.ktx.ext.hash
import com.util.ktx.ext.sharedpreferences.putSpValue
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.activity_register.view.*
import kotlinx.android.synthetic.main.title_layout.view.*
import org.koin.androidx.viewmodel.ext.android.getViewModel
import rxhttp.toBitmap
import rxhttp.toClass
import rxhttp.wrapper.param.RxHttp
import timber.log.Timber

class RegisterActivity : BaseVMActivity<LoginViewModel>() {
    // protected lateinit var binding: ViewDataBinding
    protected val notice: Notice = Notice("0", "0", "0", "0")

    protected val variables: Variables = Variables(
        "jcsA_d25e_",
        "0",
        "k3U998U2",
        "0",
        "",
        "",
        "url",
        notice,
        "ba1af646",
        "1",
        "s"
    )

    protected val variables2: Variables2 = Variables2(
        "cookiepre",
        "auth",
        "saltkey",
        "member_uid",
        "member_username",
        "member_email",
        "member_avatar",
        "groupid",
        "formhash",
        notice,
        "readaccess",
        "saltkey"

    )

    protected val registerBean: RegisterBean = RegisterBean("UTF-8", variables, "1")
    protected val message: Message = Message("messageval")

    protected val userRegisterBean: UserRegisterBean =
        UserRegisterBean("UTF-8", message, variables2, "1")


    override fun initVM(): LoginViewModel = getViewModel()

    override fun getLayoutResId() = R.layout.activity_register

    override fun initView() {
        //  binding = DataBindingUtil.setContentView(this, R.layout.activity_register)
        // binding.lifecycleOwner = this
        (mBinding as ActivityRegisterBinding).viewModel = mViewModel
        mBinding.root.toolbar.setNavigationIcon(R.mipmap.register_close)
        mBinding.root.toolbar.setMyCenterTitle(getString(R.string.register), true)
        mBinding.root.toolbar.setMySettingText(getString(R.string.login))

    }

    override fun initData() {
        bitmap()
        mBinding.root.toolbar.setNavigationOnClickListener {
            finish()
        }


        mBinding.root.toolbar.setSettingTextOnClickListener {
            start<LoginActivity>()
        }

        mBinding.root.btn_register.click {
            val email: String = et_email.text.toString().trim { it <= ' ' }
            val password: String = et_reg_pwd.text.toString().trim { it <= ' ' }
            val userName: String = et_userName.text.toString().trim({ it <= ' ' })
            val verify: String = et_verify.text.toString().trim { it <= ' ' }
            val hash = (registerBean.Variables.formhash).hash(Hash.MD5)

            if (checkData()) {
                register(
                    password,
                    userName,
                    email,
                    hash.substring(0, 8),
                    registerBean.Variables.formhash,
                    "yes",
                    registerBean.Variables.sechash,
                    verify
                )
            }

        }
        mBinding.root.tv_service_agree.click {
            Timber.e("service_agree")
            start<WebViewActivity>()
        }

        mBinding.root.iv_refresh.click {
            bitmap()
        }

    }

    private fun checkData(): Boolean {
        val email: String = et_email.text.toString().trim { it <= ' ' }
        val password: String = et_reg_pwd.text.toString().trim { it <= ' ' }
        val userName: String = et_userName.text.toString().trim({ it <= ' ' })
        val verify: String = et_verify.text.toString().trim { it <= ' ' }

        if (email.isBlank() /*|| !VerifyUtil.isEmail(email)*/) {
            toast(getString(R.string.right_mail))
            return false
        }
        if (password.isBlank() /*|| !isLengthLegal(password) || !isContainAll(password)*/) {
            toast(getString(R.string.right_password))
            return false
        }
        if (userName.isBlank()) {
            toast(getString(R.string.input_user))
            return false
        }
        if (verify.isBlank() || 4 != verify.length) {
            toast(getString(R.string.input_verify))
            return false
        }
        if (!checkBox.isChecked) {
            toast(getString(R.string.agree_service_1))
            return false
        }

        return true
    }

    private fun bitmap() = rxLifeScope.launch({
        val imageUrl =
            "https://forum.chasedream.com/api/mobile/index.php?mobile=no&version=1&module=seccode&sechash="
        val bitmap = RxHttp.get(imageUrl).toBitmap().await()
        mBinding.root.tv_show.background = BitmapDrawable(bitmap)
        getVariables()
    }, {
        mBinding.root.tv_show.text = it.message
        it.printStackTrace()
        //失败回调
        // it.show("图片加载失败,请稍后再试!")
    })

    //Variables.sechash
//Variables.formhash
//Variables.cookiepr
    private fun getVariables() = rxLifeScope.launch({
        val register =
            RxHttp.get("https://forum.chasedream.com/api/mobile/index.php?mobile=no&version=1&module=secure&type=register")
                .toClass<RegisterBean>()
                .await()
        registerBean.Variables.formhash = register.Variables.formhash
        registerBean.Variables.sechash = register.Variables.sechash
        registerBean.Variables.cookiepre = register.Variables.cookiepre
        // registerBean.variables=register.variables

    }, {
        /* mBinding.tvResult.text = it.errorMsg
         //失败回调
         it.show("发送失败,请稍后再试!")*/
    })


    private fun register(
        pwd: String, useName: String, mail: String, agreebbrule: String
        , formhash: String, regsubmit: String, seccodefhash: String, seccodeverify: String
    ) = rxLifeScope.launch({
        val userBean =
            RxHttp.postForm("https://forum.chasedream.com/api/mobile/index.php?mobile=no&version=1&module=register&handlekey=registerfrom&mod=register&inajax=1")
                .add("PWD", pwd)
                .add("PWD2", pwd)
                .add("User", useName)
                .add("UserEmail", mail)
                .add("agreebbrule", agreebbrule)
                .add("formhash", formhash)
                .add("regsubmit", regsubmit)
                .add("seccodefhash", seccodefhash)
                .add("seccodeverify", seccodeverify)
                .toClass<UserRegisterBean>()
                .await()
         Timber.e("val--------"+userBean.Message.messageval)

        if (userBean.Message.messageval.equals("register_email_verify")){
            Timber.e("messagestr--------"+userBean.Message.messagestr)
          //  toast("messagestr--------"+userBean.Message.messagestr)
           // putSpValue("userbean",userBean)
            putSpValue("pwd",pwd)
            putSpValue("mail",mail)
            putSpValue("cookiepre",userBean.Variables.cookiepre)
            toast(getString(R.string.register_sucess))
           // mViewModel.login(mail,pwd)
            start<TipActivity>()
        }
       // userRegisterBean.Message.messagestr = userBean.Message.messagestr
         else{
            toast(""+userBean.Message.messagestr)
        }

    }, {
        toast("err-> "+it.message)
        Timber.e("err--------"+it.message)
    })


    override fun startObserve() {


    }
}