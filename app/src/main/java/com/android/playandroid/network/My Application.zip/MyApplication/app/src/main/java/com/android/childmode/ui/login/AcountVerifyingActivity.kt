package com.android.childmode.ui.login

import com.android.childmode.R
import com.android.childmode.databinding.ActivityAccountVerufyingBinding
import com.android.childmode.databinding.ActivityRegisterBinding
import com.android.childmode.ui.WebViewActivity
import com.android.childmode.viewmodel.LoginViewModel
import com.android.framework.ext.click
import com.android.framework.ext.start
import com.util.ktx.base.BaseVMActivity
import kotlinx.android.synthetic.main.activity_account_verufying.view.*
import kotlinx.android.synthetic.main.activity_register.view.*
import kotlinx.android.synthetic.main.title_layout.view.*
import org.koin.androidx.viewmodel.ext.android.getViewModel
import timber.log.Timber

class AcountVerifyingActivity : BaseVMActivity<LoginViewModel>() {
    // protected lateinit var binding: ViewDataBinding
    override fun initVM(): LoginViewModel = getViewModel()

    override fun getLayoutResId() = R.layout.activity_account_verufying

    override fun initView() {
        //  binding = DataBindingUtil.setContentView(this, R.layout.activity_register)
        // binding.lifecycleOwner = this
        (mBinding as ActivityAccountVerufyingBinding).viewModel = mViewModel
        // mBinding.root.toolbar.setMyCenterTitle("注册",true)

    }

    override fun initData() {
        mBinding.root.toolbar.setMyCenterTitle(getString(R.string.account), true)
        mBinding.root.toolbar.setNavigationOnClickListener {
            finish()
        }


        mBinding.root.btn_modify_mail.click {
           // start<TipActivity>()
        }
       /* mBinding.root.tv_service_agree.click {
            Timber.e("service_agree")
            start<WebViewActivity>()
        }*/

    }

    override fun startObserve() {


    }
}