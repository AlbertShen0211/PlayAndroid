package com.android.childmode.viewmodel

import com.android.childmode.repository.HomeRepository
import com.util.ktx.base.BaseViewModel

class HomeViewModel( private val homeRepository: HomeRepository) : BaseViewModel() {


}