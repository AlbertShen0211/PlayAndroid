package com.android.childmode.bean

/**
 * Created by Albert on 2020/5/9.
 * Description:
 */
data class ModifyMailBean(
    val Charset: String,
    val Message: Message,
    val Variables: Variables4,
    val Version: String
)

data class Variables4(
    val auth: Any,
    val cookiepre: String,
    val formhash: String,
    val groupid: String,
    val ismoderator: Any,
    val member_avatar: String,
    val member_email: Any,
    val member_uid: String,
    val member_username: String,
    val notice: Notice,
    val readaccess: String,
    val saltkey: String
)
