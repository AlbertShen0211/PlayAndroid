package com.android.childmode.di

import com.android.childmode.repository.HomeRepository
import com.android.childmode.repository.LoginRepository
import com.android.childmode.viewmodel.HomeViewModel
import com.android.childmode.viewmodel.LoginViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module


val viewModelModule = module {
    viewModel { LoginViewModel(get()) }
    viewModel { HomeViewModel(get()) }
}

val repositoryModule = module {
    single { LoginRepository() }
    single { HomeRepository() }
}

val appModule = listOf(viewModelModule, repositoryModule)