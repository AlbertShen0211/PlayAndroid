package com.android.childmode.view.dialog

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.lifecycle.rxLifeScope
import com.android.childmode.R
import com.android.childmode.bean.ModifyMailBean
import com.android.childmode.bean.UserRegisterBean
import com.android.childmode.ui.login.TipActivity
import com.android.childmode.util.VerifyUtil
import com.android.framework.ext.toast
import com.flyco.animation.Attention.Swing
import com.flyco.dialog.utils.CornerUtils
import com.flyco.dialog.widget.base.BaseDialog
import com.util.ktx.ext.sharedpreferences.getSpValue
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.activity_register.checkBox
import kotlinx.android.synthetic.main.activity_register.et_userName
import kotlinx.android.synthetic.main.dialog_modify_mail.*
import kotlinx.android.synthetic.main.dialog_modify_mail.view.*
import kotlinx.android.synthetic.main.dialog_modify_mail.view.et_modify_mail
import rxhttp.toClass
import rxhttp.wrapper.param.RxHttp
import timber.log.Timber

/**
 * Created by Albert on 2020/5/5.
 * Description:
 */
class MailDialog(context: Context?) : BaseDialog<MailDialog?>(context) {
    private lateinit var dataBindingView: ViewDataBinding
    private lateinit var pwd: String
    var act: TipActivity = context as TipActivity
    override fun onCreateView(): View {
        widthScale(0.85f)
        // showAnim(Swing())
        dataBindingView = DataBindingUtil.inflate(
            LayoutInflater.from(context),
            R.layout.dialog_modify_mail,
            null,
            false
        )
        dataBindingView?.root?.setBackgroundDrawable(
            CornerUtils.cornerDrawable(
                Color.parseColor("#ffffff"),
                dp2px(5f).toFloat()
            )
        )

        val mail = act.getSpValue("mail", "")

        dataBindingView?.root.tv_mail.text=mail
        return dataBindingView?.root!!
    }

    override fun setUiBeforShow() {
        dataBindingView!!.root.btn_cancel.setOnClickListener { dismiss() }
        dataBindingView!!.root.btn_yes.setOnClickListener {
            pwd = act.getSpValue("pwd", "0")
            //  modifyMail("smmdfmfm@163.com","111aassssAA")
            if (checkData()) {
                modifyMail(et_modify_mail.text.toString(), pwd)
            }
            dismiss()
        }
        dataBindingView!!.root.iv_close.setOnClickListener { dismiss() }
    }


    private fun modifyMail(
        mail: String, pwd: String
    ) = act.rxLifeScope.launch({
        val modifyMailBean =
            RxHttp.postForm("https://forum.chasedream.com/api/mobile/index.php?mobile=no&version=1&module=myprofile&mod=spacecp&ac=profile")
                .add("oldpassword", pwd)
                .add("newpassword", pwd)
                .add("newpassword2", pwd)
                .add("emailnew", mail)
                .add("pwdsubmit", true)
                .add("passwordsubmit", true)
                .toClass<ModifyMailBean>()
                .await()

        //userRegisterBean.Message.messagestr = userBean.Message.messagestr
        // toast(modifyMailBean.Message.messagestr)
        if (modifyMailBean.Message.messageval.equals("profile_email_verify")) {
            //修改成功
        }
        Timber.e("messagestr-------------------" + modifyMailBean.Message.messagestr)
    }, {

    })

    private fun checkData(): Boolean {
        val userName: String = et_modify_mail.text.toString().trim { it <= ' ' }
        if (userName.isBlank() /*|| VerifyUtil.isEmail(userName)*/) {
            toast(act.getString(R.string.right_mail))
            return false
        }
        return true
    }

}