package com.android.childmode.ui.home

import androidx.lifecycle.Observer
import com.android.childmode.R
import com.android.childmode.viewmodel.HomeViewModel
import com.util.ktx.base.BaseVMFragment
import kotlinx.android.synthetic.main.title_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import timber.log.Timber

class HomeFragment : BaseVMFragment() {
    private val mViewModel: HomeViewModel by viewModel()
    override fun getLayoutResId() = R.layout.fragment_home

    override fun initView() {
        Timber.e("initView")

    }

    override fun initData() {
        Timber.e("initData")
    }


    override fun startObserve() {


    }
}
