package com.android.childmode.bean

/**
 * Created by Albert on 2020/5/8.
 * Description:
 *
 * {
"Version": "1",
"Charset": "UTF-8",
"Variables": {
"cookiepre": "jcsA_d25e_",
"auth": null,
"saltkey": "ryYu6DPC",
"member_uid": "0",
"member_username": "",
"member_email": null,
"member_avatar": "https:\/\/forum.chasedream.com\/uc_server\/avatar.php?uid=0&size=small",
"groupid": "7",
"formhash": "2f7902a7",
"ismoderator": null,
"readaccess": "1",
"notice": {
"newpush": "0",
"newpm": "0",
"newprompt": "0",
"newmypost": "0"
}
},
"Message": {
"messageval": "profile_email_duplicate",
"messagestr": "该 Email 地址已被注册"
}
}
 *
 *
 *
 */
data class UserRegisterBean(
    val Charset: String,
    val Message: Message,
    val Variables: Variables2,
    val Version: String
)

data class Message(
    val messageval: String
) {
    var messagestr: String = ""
}

data class Variables2(
    val auth: Any,
    val cookiepre: String,
    val formhash: String,
    val groupid: String,
    val ismoderator: Any,
    val member_avatar: String,
    val member_email: Any,
    val member_uid: String,
    val member_username: String,
    val notice: Notice,
    val readaccess: String,
    val saltkey: String
)
