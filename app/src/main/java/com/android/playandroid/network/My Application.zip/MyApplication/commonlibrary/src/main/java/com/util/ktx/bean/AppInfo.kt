package com.util.ktx.bean

import android.graphics.drawable.Drawable

data class AppInfo(
    val apkPath: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val appName: String,
    val icon: Drawable
)