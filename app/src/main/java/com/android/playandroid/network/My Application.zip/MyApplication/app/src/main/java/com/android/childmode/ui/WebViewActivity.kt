package com.android.childmode.ui

import android.webkit.WebSettings
import com.android.childmode.R
import com.android.childmode.viewmodel.LoginViewModel
import com.github.lzyzsd.jsbridge.BridgeWebView
import com.util.ktx.base.BaseVMActivity
import kotlinx.android.synthetic.main.activity_web_login.view.*
import kotlinx.android.synthetic.main.title_layout.view.*
import org.koin.androidx.viewmodel.ext.android.getViewModel
import timber.log.Timber


class WebViewActivity : BaseVMActivity<LoginViewModel>() {
    override fun initVM(): LoginViewModel = getViewModel()
    override fun getLayoutResId() = R.layout.activity_web_login
    lateinit var webView: BridgeWebView
    //protected lateinit var binding: ViewDataBinding
    override fun initView() {
       // binding = DataBindingUtil.setContentView(this, R.layout.activity_login)

        mBinding.root.toolbar.setMySettingIcon(R.mipmap.register_close)
        mBinding.root.toolbar.navigationIcon = null
        val settings: WebSettings =   mBinding.root.webView.getSettings()
        settings.textZoom=80
        mBinding.root.webView.loadUrl("file:///android_asset/agreement.html")
    }


    override fun initData() {
        Timber.e("initData")
       /* mBinding.root.btn_register.click {
            start<RegisterActivity>()
        }
        mBinding.root.tv_service_agree.click {
            Timber.e("service_agree")
        }*/
        mBinding.root.toolbar.setSettingIconOnClickListener {
            finish()
        }
    }

    override fun startObserve() {
        Timber.e("startObserve")

    }
}