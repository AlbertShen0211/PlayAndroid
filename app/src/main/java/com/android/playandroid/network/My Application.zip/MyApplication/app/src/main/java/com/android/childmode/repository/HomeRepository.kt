package com.android.childmode.repository

import com.util.ktx.base.BaseRepository
import com.android.childmode.bean.Banner
import com.util.ktx.base.basebean.Results

class HomeRepository : BaseRepository() {


}
