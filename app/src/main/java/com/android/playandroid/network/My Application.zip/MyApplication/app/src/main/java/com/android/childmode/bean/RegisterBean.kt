package com.android.childmode.bean

/**
 * Created by Albert on 2020/5/8.
 * Description:
 */
data class RegisterBean(
    val Charset: String,
    val Variables: Variables,
    val Version: String
){

}

data class Variables(
    val auth: Any,
    val groupid: String,
    val ismoderator: Any,
    val member_avatar: String,
    val member_email: Any,
    val member_uid: String,
    val member_username: String,
    val notice: Notice,
    val readaccess: String,
    val saltkey: String,
    var sechash: String
){
    var formhash: String=""
    val seccode: String=""
    var cookiepre: String=""
}

data class Notice(
    val newmypost: String,
    val newpm: String,
    val newprompt: String,
    val newpush: String
)
