package com.android.childmode.ui.login

import android.graphics.Color
import android.os.CountDownTimer
import android.util.Log
import androidx.lifecycle.rxLifeScope
import com.android.childmode.R
import com.android.childmode.bean.RegisterBean
import com.android.childmode.bean.ResentMailBean
import com.android.childmode.bean.UserRegisterBean
import com.android.childmode.databinding.ActivityTipBinding
import com.android.childmode.view.dialog.MailDialog
import com.android.childmode.viewmodel.LoginViewModel
import com.android.framework.ext.click
import com.android.framework.ext.start
import com.android.framework.ext.toast
import com.util.ktx.base.BaseVMActivity
import com.util.ktx.ext.sharedpreferences.getSpValue
import com.util.ktx.ext.sharedpreferences.putSpValue
import kotlinx.android.synthetic.main.activity_tip.*
import kotlinx.android.synthetic.main.activity_tip.view.*
import kotlinx.android.synthetic.main.activity_tip.view.btn_mail_resent
import kotlinx.android.synthetic.main.title_layout.view.*
import org.koin.androidx.viewmodel.ext.android.getViewModel
import rxhttp.toClass
import rxhttp.wrapper.param.RxHttp

class TipActivity : BaseVMActivity<LoginViewModel>() {
     //protected lateinit var bean: UserRegisterBean
     protected lateinit var cookiepre: String
     protected lateinit var mail: String
    override fun initVM(): LoginViewModel = getViewModel()
    override fun getLayoutResId() = R.layout.activity_tip


    override fun initView() {
        //  binding = DataBindingUtil.setContentView(this, R.layout.activity_register)
        // binding.lifecycleOwner = this
        (mBinding as ActivityTipBinding).viewModel = mViewModel
        // mBinding.root.toolbar.setMyCenterTitle("注册",true)
        //  mBinding.root.toolbar.navigationIcon.setLayoutDirection()
       //  bean = getSpValue("userbean", bean)
        cookiepre = getSpValue("cookiepre", "")
        mail = getSpValue("mail", "")
      //  bean = getSpValue("userbean", null) as UserRegisterBean
    }

    override fun initData() {
        mBinding.root.toolbar.setMyCenterTitle(getString(R.string.tip), true)
        mBinding.root.toolbar.setNavigationOnClickListener {
            finish()
        }
        tv_mail_spell.text=mail
        mBinding.root.btn_mail_spell.click { //修改电子邮件
            val dialog = MailDialog(this)
            dialog.show()
            dialog.setCanceledOnTouchOutside(false)
        }
        mBinding.root.btn_mail_resent.click { //重发验证码邮件
            resentMail()
            toast(getString(R.string.receive_verify_mail))
        }
        mBinding.root.btn_surport.click { //联系技术
            start<ContactSupportActivity>()
        }
        mBinding.root.btn_run.click { //逛一逛
            toast("开发中")
        }
        mBinding.root.btn_finished_verify.click { //已完成验证
            toast("开发中")
        }

    }

    private fun resentMail() = rxLifeScope.launch({


      var mail= cookiepre+"newemail="+mail
        val resentMailBean =
            RxHttp.get("https://forum.chasedream.com/api/mobile/index.php?mobile=no&version=1&module=resendemail&resend=1")
                .addHeader("Cookie",mail)
                .toClass<ResentMailBean>()
                .await()
        var count = object : CountDownTimer(100000, 1000) {

            override fun onFinish() {
                btn_mail_resent.setEnabled(true)
                btn_mail_resent.setBackgroundColor(Color.parseColor("#2BC345"))
                tv_counter.setText("")
            }

            override fun onTick(millisUntilFinished: Long) {
                btn_mail_resent.setBackgroundColor(Color.parseColor("#CCCCCC"))
                btn_mail_resent.setEnabled(false)
                var counter: String = "" + millisUntilFinished / 1000
                tv_counter.setText(counter + getString(R.string.again_sent))
            }
        }.start()


    }, {
        btn_mail_resent.setEnabled(true)
        btn_mail_resent.setBackgroundColor(Color.parseColor("#2BC345"))
        tv_counter.setText("")
    })

    override fun startObserve() {


    }
}