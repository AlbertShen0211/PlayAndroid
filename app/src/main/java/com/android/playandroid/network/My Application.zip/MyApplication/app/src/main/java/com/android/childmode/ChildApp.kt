package com.android.childmode

import android.app.Application
import android.content.Context
import com.android.childmode.di.appModule
import com.android.childmode.network.HttpManager
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import timber.log.Timber
import kotlin.properties.Delegates

class ChildApp : Application() {

    companion object {
        var appContext: Context by Delegates.notNull()
        val instance: ChildApp by lazy(mode = LazyThreadSafetyMode.SYNCHRONIZED){
            ChildApp()
        }
    }

    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext

        HttpManager.init(this)
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())
        startKoin {
            androidContext(this@ChildApp)
            modules(appModule)
        }
    }
}