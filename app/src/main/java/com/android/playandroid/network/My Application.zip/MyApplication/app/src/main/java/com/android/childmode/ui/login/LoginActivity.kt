package com.android.childmode.ui.login

import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.lifecycle.rxLifeScope
import com.android.childmode.R
import com.android.childmode.bean.LoginBean
import com.android.childmode.bean.UserRegisterBean
import com.android.childmode.databinding.ActivityLoginBinding
import com.android.childmode.ui.MainActivity
import com.android.childmode.ui.WebViewActivity
import com.android.childmode.util.VerifyUtil
import com.android.childmode.viewmodel.LoginViewModel
import com.android.framework.ext.click
import com.android.framework.ext.start
import com.android.framework.ext.toast
import com.util.ktx.base.BaseVMActivity
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_login.view.*
import kotlinx.android.synthetic.main.activity_login.view.checkBox
import kotlinx.android.synthetic.main.activity_login.view.et_password
import kotlinx.android.synthetic.main.activity_login.view.et_userName
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.activity_register.checkBox
import kotlinx.android.synthetic.main.activity_register.et_userName
import org.koin.androidx.viewmodel.ext.android.getViewModel
import rxhttp.toClass
import timber.log.Timber
import java.util.*

class LoginActivity : BaseVMActivity<LoginViewModel>() {
    override fun initVM(): LoginViewModel = getViewModel()
    override fun getLayoutResId() = R.layout.activity_login

    //protected lateinit var binding: ViewDataBinding
    override fun initView() {
        // binding = DataBindingUtil.setContentView(this, R.layout.activity_login)

    }


    override fun initData() {
        Timber.e("initData")
        mBinding.root.btn_register.click {
            start<RegisterActivity>()
        }
        mBinding.root.tv_service_agree.click {
            Timber.e("service_agree")
            start<WebViewActivity>()
        }
        mBinding.root.tv_run.click {
            toast("开发中")
        }

        mBinding.root.btn_login.click {
            val userName: String = et_userName.text.toString().trim { it <= ' ' }
            val password: String = et_password.text.toString().trim { it <= ' ' }
            //  mViewModel.login("ssssss@163.com", "ssss1112XXX")
            if (checkData()) {
               mViewModel.login(userName, password)
              //  mViewModel.login("P9631aH1zbggg@qq.com", "Qazwsx123")
            }
        }
    }

    private fun checkData(): Boolean {
        val userName: String = et_userName.text.toString().trim { it <= ' ' }
        val password: String = et_password.text.toString().trim { it <= ' ' }

        if (userName.isBlank() /*|| VerifyUtil.isEmail(userName)*/) {
            toast(getString(R.string.right_mail))
            return false
        }
        if (password.isBlank()) {
            toast(getString(R.string.input))
            return false

        }
        /*if (!VerifyUtil.isLengthLegal(password) || !VerifyUtil.isContainAll(password)) {
            toast(getString(R.string.right_password))
            return false
        }*/

        if (!checkBox.isChecked) {
            toast(getString(R.string.service_agree))
            return false
        }

        return true
    }


    override fun startObserve() {

        mViewModel.loginBean.observe(this, androidx.lifecycle.Observer {
            Timber.e("startObserve:" + it.Message.messageval)
            if (it.Message.messageval == "login_succeed"||it.Message.messageval == "login_succeed_inactive_member") {//登录成功
                toast("跳到主界面")
                start<MainActivity>()
            } else
                toast(it.Message.messagestr)
        })

        mViewModel.ok.observe(this, androidx.lifecycle.Observer {
            if (false == it) {
                mViewModel.err.observe(this, androidx.lifecycle.Observer {
                    toast(it)
                })
            }

        })
        /*  if (mViewModel.ok.value==false)
             toast((""+mViewModel.err.value))*/
    }
}