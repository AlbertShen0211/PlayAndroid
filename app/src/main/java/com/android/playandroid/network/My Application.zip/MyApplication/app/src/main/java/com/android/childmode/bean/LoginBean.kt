package com.android.childmode.bean

/**
 * Created by Albert on 2020/5/8.
 * Description:
 *
 * {
"Version": "1",
"Charset": "UTF-8",
"Variables": {
"cookiepre": "jcsA_d25e_",
"auth": null,
"saltkey": "Mwp7u1x8",
"member_uid": "0",
"member_username": "",
"member_email": null,
"member_avatar": "https:\/\/forum.chasedream.com\/uc_server\/avatar.php?uid=0&size=small",
"groupid": "7",
"formhash": "b805c9da",
"ismoderator": null,
"readaccess": "1",
"notice": {
"newpush": "0",
"newpm": "0",
"newprompt": "0",
"newmypost": "0"
},
"allowperm": {
"allowpost": "0",
"allowreply": "0",
"uploadhash": "05427370678e5ee557b93c12655e6f84"
}
},
"Message": {
"messageval": "login_invalid",
"messagestr": "Email或密码错，还可尝试 4 次"
}
}
 *
 *
 */
data class LoginBean(
    val Charset: String,
    val Message: Message,
    val Variables: Variables3,
    val Version: String
)


data class Variables3(
    val allowperm: Allowperm,
    val auth: Any,
    val cookiepre: String,
    val formhash: String,
    val groupid: String,
    val ismoderator: Any,
    val member_avatar: String,
    val member_email: Any,
    val member_uid: String,
    val member_username: String,
    val notice: Notice,
    val readaccess: String,
    val saltkey: String
)

data class Allowperm(
    val allowpost: String,
    val allowreply: String,
    val uploadhash: String
)
